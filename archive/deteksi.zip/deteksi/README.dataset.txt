# deteksi sampah > 2024-06-24 11:40am
https://universe.roboflow.com/deep-learning-xiqhb/deteksi-sampah-z0fg7

Provided by a Roboflow user
License: CC BY 4.0

